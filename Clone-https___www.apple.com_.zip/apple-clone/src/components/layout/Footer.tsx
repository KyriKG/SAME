import Link from "next/link";

const footerSections = [
  {
    title: "Shop and Learn",
    links: [
      { name: "Store", href: "/store" },
      { name: "Mac", href: "/mac" },
      { name: "iPad", href: "/ipad" },
      { name: "iPhone", href: "/iphone" },
      { name: "Watch", href: "/watch" },
      { name: "Vision", href: "/vision" },
      { name: "AirPods", href: "/airpods" },
      { name: "TV & Home", href: "/tv-home" },
      { name: "AirTag", href: "/airtag" },
      { name: "Accessories", href: "/accessories" },
      { name: "Gift Cards", href: "/gift-cards" },
    ],
  },
  {
    title: "Apple Store",
    links: [
      { name: "Find a Store", href: "/find-a-store" },
      { name: "Genius Bar", href: "/genius-bar" },
      { name: "Today at Apple", href: "/today-at-apple" },
      { name: "Apple Camp", href: "/apple-camp" },
      { name: "Apple Trade In", href: "/trade-in" },
      { name: "Ways to Buy", href: "/ways-to-buy" },
      { name: "Recycling Programme", href: "/recycling" },
      { name: "Order Status", href: "/order-status" },
      { name: "Shopping Help", href: "/shopping-help" },
    ],
  },
  {
    title: "For Business",
    links: [
      { name: "Apple and Business", href: "/business" },
      { name: "Shop for Business", href: "/business/shop" },
    ],
  },
  {
    title: "For Education",
    links: [
      { name: "Apple and Education", href: "/education" },
      { name: "Shop for Education", href: "/education/shop" },
      { name: "Shop for University", href: "/education/university" },
    ],
  },
  {
    title: "For Healthcare",
    links: [
      { name: "Apple in Healthcare", href: "/healthcare" },
      { name: "Health on Apple Watch", href: "/healthcare/apple-watch" },
    ],
  },
  {
    title: "Entertainment",
    links: [
      { name: "Apple One", href: "/apple-one" },
      { name: "Apple TV+", href: "/apple-tv-plus" },
      { name: "Apple Music", href: "/apple-music" },
      { name: "Apple Arcade", href: "/apple-arcade" },
      { name: "Apple Fitness+", href: "/fitness-plus" },
      { name: "Apple News+", href: "/news-plus" },
      { name: "Apple Podcasts", href: "/podcasts" },
      { name: "Apple Books", href: "/books" },
      { name: "App Store", href: "/app-store" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="bg-[#f5f5f7] text-[#6e6e73] text-xs">
      <div className="max-w-5xl mx-auto px-4 py-12">
        {/* Legal disclaimer */}
        <div className="border-b border-[#d2d2d7] pb-4 mb-7">
          <p className="mb-3">
            1. AirPods Pro can be used as hearing aids in supported regions by
            people 18 years or older with mild to moderate hearing loss.
          </p>
          <p>
            Apple Footer. Trade‑in values will vary based on the condition, year
            and configuration of your trade-in device. You must be at least 18
            years old to be eligible to trade in for credit or for an Apple Gift
            Card. Trade‑in value may be applied towards a qualifying new device
            purchase, or added to an Apple Gift Card. Actual value awarded is
            based on receipt of a qualifying device matching the description
            provided when estimate was made. In-store trade‑in requires
            presentation of a valid photo ID. Offer may not be available in all
            stores and not all devices are eligible for credit. Apple or its
            trade-in partners reserve the right to refuse or limit any trade-in
            transaction for any reason. Additional terms from Apple or Apple's
            trade-in partners may apply.
          </p>
        </div>

        {/* Main footer grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-10">
          {footerSections.map((section) => (
            <div key={section.title}>
              <h3 className="font-semibold text-[#1d1d1f] mb-2">
                {section.title}
              </h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom footer */}
        <div className="mt-12 border-t border-[#d2d2d7] pt-4 flex flex-col md:flex-row md:justify-between">
          <p className="mb-2 md:mb-0">
            Copyright © {new Date().getFullYear()} Apple Inc. All rights
            reserved.
          </p>
          <div className="flex flex-wrap gap-x-6 gap-y-1">
            <Link
              href="/privacy"
              className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
            >
              Privacy Policy
            </Link>
            <Link
              href="/legal"
              className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
            >
              Terms of Use
            </Link>
            <Link
              href="/sales"
              className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
            >
              Sales and Refunds
            </Link>
            <Link
              href="/legal/privacy"
              className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
            >
              Legal
            </Link>
            <Link
              href="/sitemap"
              className="text-[#6e6e73] hover:text-[#1d1d1f] hover:underline"
            >
              Site Map
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
