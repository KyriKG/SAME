import Link from "next/link";
import { ChevronRight } from "lucide-react";

interface HeroSectionProps {
  title: string;
  subtitle: string;
  backgroundImage: string;
  backgroundPosition?: string;
  textColor?: string;
  learnMoreLink: string;
  buyLink: string;
  backgroundColor?: string;
}

export function HeroSection({
  title,
  subtitle,
  backgroundImage,
  backgroundPosition = "center",
  textColor = "text-white",
  learnMoreLink,
  buyLink,
  backgroundColor,
}: HeroSectionProps) {
  return (
    <section
      className={`relative w-full min-h-[580px] flex flex-col items-center justify-start pt-16 ${
        backgroundColor || ""
      }`}
      style={{
        backgroundImage: `url(${backgroundImage})`,
        backgroundPosition,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <div className="text-center z-10">
        <h2
          className={`text-4xl md:text-5xl font-semibold tracking-tight mb-1 ${textColor}`}
        >
          {title}
        </h2>
        <h3 className={`text-xl md:text-2xl mb-4 ${textColor}`}>{subtitle}</h3>
        <div className="flex items-center justify-center gap-7">
          <Link
            href={learnMoreLink}
            className="text-blue-500 hover:underline flex items-center"
          >
            Learn more <ChevronRight className="h-4 w-4" />
          </Link>
          <Link
            href={buyLink}
            className="text-blue-500 hover:underline flex items-center"
          >
            Buy <ChevronRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
