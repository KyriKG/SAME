import Link from "next/link";
import Image from "next/image";
import { ChevronRight } from "lucide-react";

interface ProductGridItemProps {
  title: string;
  subtitle?: string;
  description?: string;
  backgroundImage: string;
  backgroundPosition?: string;
  textColor?: string;
  learnMoreLink?: string;
  buyLink?: string;
  backgroundColor?: string;
  logo?: string;
  isFullWidth?: boolean;
}

export function ProductGridItem({
  title,
  subtitle,
  description,
  backgroundImage,
  backgroundPosition = "center",
  textColor = "text-black",
  learnMoreLink,
  buyLink,
  backgroundColor = "bg-[#f5f5f7]",
  logo,
  isFullWidth = false,
}: ProductGridItemProps) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl ${
        isFullWidth ? "col-span-full" : ""
      } ${backgroundColor}`}
      style={{
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : "none",
        backgroundPosition,
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <div className="p-8 md:p-12 flex flex-col items-center text-center z-10 relative min-h-[400px]">
        {logo ? (
          <div className="mb-3">
            <img src={logo} alt={`${title} logo`} className="w-[150px] h-auto" />
          </div>
        ) : (
          <h2
            className={`text-3xl md:text-4xl font-semibold tracking-tight mb-1 ${textColor}`}
          >
            {title}
          </h2>
        )}

        {subtitle && (
          <h3 className={`text-lg md:text-xl mb-2 ${textColor}`}>{subtitle}</h3>
        )}

        {description && (
          <p className={`text-sm mb-4 max-w-xs mx-auto ${textColor}`}>
            {description}
          </p>
        )}

        {(learnMoreLink || buyLink) && (
          <div className="flex items-center justify-center gap-5 mt-2">
            {learnMoreLink && (
              <Link
                href={learnMoreLink}
                className="text-blue-500 hover:underline flex items-center text-sm"
              >
                Learn more <ChevronRight className="h-3 w-3" />
              </Link>
            )}
            {buyLink && (
              <Link
                href={buyLink}
                className="text-blue-500 hover:underline flex items-center text-sm"
              >
                Buy <ChevronRight className="h-3 w-3" />
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
