import { HeroSection } from "@/components/home/HeroSection";
import { ProductGridItem } from "@/components/home/ProductGridItem";

// Define image URLs as constants to avoid string interpolation issues
const IPHONE_16_PRO_BG = "https://ext.same-assets.com/2440757773/3733483097.jpg";
const IPHONE_16_BG = "https://ext.same-assets.com/2440757773/2598795345.jpg";
const APPLE_WATCH_BG = "https://ext.same-assets.com/2440757773/1243642780.jpg";
const WWDC_BG = "https://ext.same-assets.com/2440757773/3747647991.jpg";
const MACBOOK_AIR_BG = "https://ext.same-assets.com/2440757773/1193962101.jpg";
const IPAD_AIR_BG = "https://ext.same-assets.com/2440757773/1417994051.jpg";
const AIRPODS_PRO_BG = "https://ext.same-assets.com/2440757773/3341254051.jpg";
const TRADE_IN_BG = "https://ext.same-assets.com/2440757773/485710749.png";
const APPLE_CARD_BG = "https://ext.same-assets.com/2440757773/998056807.png";

export default function Home() {
  return (
    <div className="flex flex-col gap-3 px-3 py-3">
      {/* iPhone 16 Pro Hero */}
      <HeroSection
        title="iPhone 16 Pro"
        subtitle="Hello, Apple Intelligence."
        backgroundImage={IPHONE_16_PRO_BG}
        backgroundPosition="center bottom"
        textColor="text-white"
        learnMoreLink="/iphone-16-pro"
        buyLink="/store/iphone-16-pro"
        backgroundColor="bg-black"
      />

      {/* iPhone 16 Hero */}
      <HeroSection
        title="iPhone 16"
        subtitle="Hello, Apple Intelligence."
        backgroundImage={IPHONE_16_BG}
        backgroundPosition="center"
        textColor="text-black"
        learnMoreLink="/iphone-16"
        buyLink="/store/iphone-16"
        backgroundColor="bg-[#94a8c6]"
      />

      {/* Apple Watch */}
      <HeroSection
        title="WATCH"
        subtitle="Live healthier. Train better. Stay connected."
        backgroundImage={APPLE_WATCH_BG}
        backgroundPosition="center"
        textColor="text-black"
        learnMoreLink="/watch"
        buyLink="/store/watch"
        backgroundColor="bg-[#f5f5f7]"
      />

      {/* Product Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* WWDC 25 */}
        <ProductGridItem
          title="WWDC 25"
          subtitle="Apple Worldwide Developers Conference."
          description="Join us online June 9-13."
          backgroundImage={WWDC_BG}
          textColor="text-black"
          learnMoreLink="/wwdc25"
          backgroundColor="bg-[#f5f5f7]"
        />

        {/* MacBook Air */}
        <ProductGridItem
          title="MacBook Air"
          subtitle="Sky blue color. Sky high performance with M4."
          backgroundImage={MACBOOK_AIR_BG}
          textColor="text-black"
          learnMoreLink="/macbook-air"
          buyLink="/store/macbook-air"
          backgroundColor="bg-[#f5f5f7]"
        />

        {/* iPad Air */}
        <ProductGridItem
          title="iPad Air"
          subtitle="Now supercharged by the M3 chip."
          backgroundImage={IPAD_AIR_BG}
          textColor="text-black"
          learnMoreLink="/ipad-air"
          buyLink="/store/ipad-air"
          backgroundColor="bg-[#f5f5f7]"
        />

        {/* AirPods Pro 2 */}
        <ProductGridItem
          title="AirPods Pro 2"
          subtitle="Now with a Hearing Aid feature."
          backgroundImage={AIRPODS_PRO_BG}
          textColor="text-white"
          learnMoreLink="/airpods-pro"
          buyLink="/store/airpods-pro"
          backgroundColor="bg-black"
        />

        {/* Apple Trade In */}
        <ProductGridItem
          title="Trade In"
          subtitle="Get $170-$650 in credit when you trade in iPhone 12 or higher."
          backgroundImage={TRADE_IN_BG}
          textColor="text-black"
          learnMoreLink="/trade-in"
          backgroundColor="bg-[#f5f5f7]"
        />

        {/* Apple Card */}
        <ProductGridItem
          title="Card"
          subtitle="Get up to 3% Daily Cash back with every purchase."
          backgroundImage={APPLE_CARD_BG}
          textColor="text-black"
          learnMoreLink="/apple-card"
          backgroundColor="bg-[#f5f5f7]"
        />
      </div>
    </div>
  );
}
