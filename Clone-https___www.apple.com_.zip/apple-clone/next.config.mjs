/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true,
    // Remove domains to eliminate hydration mismatch with static export
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'ext.same-assets.com',
      },
      {
        protocol: 'https',
        hostname: 'same-assets.com',
      },
      {
        protocol: 'https',
        hostname: 'www.apple.com',
      },
    ],
  },
  reactStrictMode: false, // Disable strict mode to avoid double-rendering issues
  distDir: 'out',
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
